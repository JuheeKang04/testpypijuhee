import kss

def testfuncjuhee(text):
    print('아 이것은 kss 테스트입니다!')
    split_list = kss.split_sentences(text)
    return split_list